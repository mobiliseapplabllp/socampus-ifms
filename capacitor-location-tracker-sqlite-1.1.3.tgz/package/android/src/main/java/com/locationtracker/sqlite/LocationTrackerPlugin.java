package com.locationtracker.sqlite;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.List;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "LocationTracker", requestCodes = {1001})
public class LocationTrackerPlugin extends Plugin {

    @PluginMethod
    public void start(PluginCall call) {
        Context context = getContext();

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            call.reject("Location permission not granted");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            call.reject("Background location permission not granted");
            return;
        }

        try {
            // Persist tracking state so WatchdogReceiver and BootReceiver know to restart
            context.getSharedPreferences("location_tracker_prefs", Context.MODE_PRIVATE)
                    .edit().putBoolean("tracking_enabled", true).apply();

            Intent i = new Intent(context, TrackerService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i);
            } else {
                context.startService(i);
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to start service: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try {
            // Clear tracking state so WatchdogReceiver/BootReceiver don't auto-restart
            getContext().getSharedPreferences("location_tracker_prefs", Context.MODE_PRIVATE)
                    .edit().putBoolean("tracking_enabled", false).apply();

            Intent i = new Intent(getContext(), TrackerService.class);
            getContext().stopService(i);
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to stop service: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void getLocations(PluginCall call) {
        Cursor cursor = null;
        try {
            LocationDbHelper dbHelper = LocationDbHelper.getInstance(getContext());
            cursor = dbHelper.getAllLocations();

            JSArray arr = new JSArray();
            if (cursor.moveToFirst()) {
                do {
                    JSObject obj = new JSObject();
                    obj.put("latitude", cursor.getDouble(0));
                    obj.put("longitude", cursor.getDouble(1));
                    obj.put("timestamp", String.valueOf(cursor.getLong(2)));
                    arr.put(obj);
                } while (cursor.moveToNext());
            }

            JSObject ret = new JSObject();
            ret.put("locations", arr);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to fetch locations: " + e.getMessage(), e);
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    @PluginMethod
    public void clearLocations(PluginCall call) {
        try {
            LocationDbHelper dbHelper = LocationDbHelper.getInstance(getContext());
            dbHelper.clearLocations();
            call.resolve();
        } catch (Exception e) {
            call.reject("Failed to clear locations: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void requestBackgroundPermissionsCheck(PluginCall call) {
        try {
            Context context = getContext();
            boolean allowed = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                allowed = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED;
            }
            JSObject ret = new JSObject();
            ret.put("allowed", allowed);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Location permission error: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestBackgroundPermissions(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve(new JSObject().put("opened", true));
        } catch (Exception e) {
            call.reject("Open location settings failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestIgnoreBatteryOptimizationsCheck(PluginCall call) {
        try {
            Context context = getContext();
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            boolean ignoring = pm != null && pm.isIgnoringBatteryOptimizations(context.getPackageName());
            JSObject ret = new JSObject();
            ret.put("allowed", ignoring);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Battery check failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestIgnoreBatteryOptimizations(PluginCall call) {
        try {
            Context context = getContext();
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(context.getPackageName())) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (getActivity() != null) {
                    getActivity().startActivity(intent);
                } else {
                    context.startActivity(intent);
                }
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to request battery optimizations: " + e.getMessage());
        }
    }

    /**
     * Opens OEM-specific battery/auto-start settings.
     * OPPO/Realme (ColorOS), Xiaomi (MIUI), Vivo, Huawei all have their own screens
     * that standard Android intents cannot reach. Guide the user to allow auto-start there.
     */
    @PluginMethod
    public void openOemBatterySettings(PluginCall call) {
        Context context = getContext();
        String manufacturer = Build.MANUFACTURER.toLowerCase();
        List<Intent> intents = new ArrayList<>();

        if (manufacturer.contains("oppo") || manufacturer.contains("realme")) {
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.coloros.safecenter",
                    "com.coloros.safecenter.permission.startup.StartupAppListActivity")));
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.oppo.safe",
                    "com.oppo.safe.permission.startup.StartupAppListActivity")));
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.color.safecenter",
                    "com.color.safecenter.permission.startup.StartupAppListActivity")));
        } else if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity")));
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.miui.powerkeeper",
                    "com.miui.powerkeeper.ui.HideAppSelectedActivity")));
        } else if (manufacturer.contains("vivo") || manufacturer.contains("iqoo")) {
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.vivo.permissionmanager",
                    "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")));
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.iqoo.secure",
                    "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")));
        } else if (manufacturer.contains("huawei") || manufacturer.contains("honor")) {
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.startemission.AppStartupActivity")));
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.optimize.process.ProtectActivity")));
        } else if (manufacturer.contains("samsung")) {
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.samsung.android.lool",
                    "com.samsung.android.sm.ui.battery.BatteryActivity")));
        } else if (manufacturer.contains("oneplus")) {
            intents.add(new Intent().setComponent(new ComponentName(
                    "com.oneplus.security",
                    "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")));
        }

        // Fallback: standard Android battery optimization settings
        intents.add(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));

        boolean opened = false;
        for (Intent intent : intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                opened = true;
                break;
            } catch (Exception ignored) {
                // Intent not available on this device, try next
            }
        }

        JSObject ret = new JSObject();
        ret.put("opened", opened);
        ret.put("manufacturer", Build.MANUFACTURER);
        call.resolve(ret);
    }

    @PluginMethod
    public void isTracking(PluginCall call) {
        boolean tracking = getContext()
                .getSharedPreferences("location_tracker_prefs", Context.MODE_PRIVATE)
                .getBoolean("tracking_enabled", false);
        call.resolve(new JSObject().put("tracking", tracking));
    }

    @PluginMethod
    public void ping(PluginCall call) {
        call.resolve(new JSObject().put("pong", true));
    }
}
