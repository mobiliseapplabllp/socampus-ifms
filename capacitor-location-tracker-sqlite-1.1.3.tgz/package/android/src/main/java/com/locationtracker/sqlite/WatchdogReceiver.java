package com.locationtracker.sqlite;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;

public class WatchdogReceiver extends BroadcastReceiver {

    private static final long WATCHDOG_INTERVAL_MS = 5 * 60 * 1000L;

    @Override
    public void onReceive(Context context, Intent intent) {
        boolean shouldRun = context
                .getSharedPreferences("location_tracker_prefs", Context.MODE_PRIVATE)
                .getBoolean("tracking_enabled", false);

        if (!shouldRun) return;

        // Restart service (safe to call even if already running — just calls onStartCommand again)
        Intent serviceIntent = new Intent(context, TrackerService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }

        // Schedule NEXT watchdog here as well — so even if service gets killed before
        // it can schedule its own alarm, this chain keeps the loop alive
        scheduleNext(context);
    }

    /**
     * Self-chain: schedule the next watchdog alarm so the loop never breaks
     * even if the service is killed between alarms.
     */
    private void scheduleNext(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent watchdog = new Intent(context, WatchdogReceiver.class);
        watchdog.setAction(TrackerService.WATCHDOG_ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 0, watchdog,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        long triggerAt = SystemClock.elapsedRealtime() + WATCHDOG_INTERVAL_MS;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
        } else {
            am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
        }
    }
}
