package com.locationtracker.sqlite;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TrackerService extends Service {

    private static final String CHANNEL_ID = "location_tracker_channel";
    private static final float MAX_ACCURACY = 40f;
    private static final int NOTIF_ID = 1;

    static final String WATCHDOG_ACTION = "com.locationtracker.sqlite.WATCHDOG";
    // Every 5 minutes — fires even in Doze mode via setExactAndAllowWhileIdle
    private static final long WATCHDOG_INTERVAL_MS = 5 * 60 * 1000L;

    private double lastLat = 0;
    private double lastLng = 0;
    private long lastTime = 0;

    private boolean gpsReady = false;
    private int warmupCount = 0;

    private FusedLocationProviderClient fused;
    private LocationCallback callback;
    private PowerManager.WakeLock wakeLock;
    // Single background thread for DB writes — keeps main thread free
    private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();

        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Location Tracker")
                .setContentText("Background location active")
                .setSmallIcon(com.locationtracker.sqlite.R.drawable.ic_location_tracker)
                .setOngoing(true)
                .build();

        startForeground(NOTIF_ID, n);

        // WakeLock — prevents CPU from sleeping so location callbacks keep firing
        // Critical for OPPO, Xiaomi, Vivo and other aggressive OEMs
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocationTracker:WakeLock");
            if (!wakeLock.isHeld()) {
                wakeLock.acquire();
            }
        }

        Location last = LocationDbHelper.getInstance(getApplicationContext()).getLastLocation();
        if (last != null) {
            lastLat = last.getLatitude();
            lastLng = last.getLongitude();
            lastTime = last.getTime();
            Log.d("LocationTracker", "Restored last location from DB");
        }

        fused = LocationServices.getFusedLocationProviderClient(this);
        startLocationUpdates();
        scheduleWatchdog(); // Start the periodic self-chaining watchdog
    }

    private void startLocationUpdates() {
        LocationRequest req;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            req = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10_000)
                    .setMinUpdateIntervalMillis(5_000)
                    .setMinUpdateDistanceMeters(20)
                    .build();
        } else {
            req = LocationRequest.create()
                    .setInterval(10_000)
                    .setFastestInterval(5_000)
                    .setSmallestDisplacement(20)
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }

        callback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult result) {
                if (result == null) return;

                for (Location loc : result.getLocations()) {
                    if (System.currentTimeMillis() - loc.getTime() > 15000) continue;

                    float accuracy = loc.getAccuracy();
                    float speed = loc.hasSpeed() ? loc.getSpeed() : 0f;

                    if (accuracy == 0 || accuracy > MAX_ACCURACY) continue;

                    if (!gpsReady) {
                        warmupCount++;
                        if (accuracy <= 30 && loc.hasSpeed()) {
                            gpsReady = true;
                            Log.d("LocationTracker", "GPS warmed up");
                        } else {
                            if (warmupCount < 3) continue;
                        }
                    }

                    double lat = loc.getLatitude();
                    double lng = loc.getLongitude();

                    float minMove, maxJump;
                    if (speed < 0.5f) {
                        minMove = 30;
                        maxJump = 50;
                    } else if (speed < 2f) {
                        minMove = 15;
                        maxJump = 80;
                    } else if (speed < 6f) {
                        minMove = 25;
                        maxJump = 150;
                    } else {
                        minMove = 50;
                        maxJump = 300;
                    }

                    if (lastLat != 0 && lastLng != 0) {
                        float[] dist = new float[1];
                        Location.distanceBetween(lastLat, lastLng, lat, lng, dist);
                        if (dist[0] < minMove) continue;
                        if (dist[0] > maxJump) continue;
                    }

                    lastLat = lat;
                    lastLng = lng;
                    lastTime = System.currentTimeMillis();

                    // Write to SQLite on background thread — keeps main thread free
                    final double saveLat = lat;
                    final double saveLng = lng;
                    final long saveTime = lastTime;
                    dbExecutor.execute(() ->
                            LocationDbHelper.getInstance(getApplicationContext())
                                    .insertLocation(saveLat, saveLng, saveTime)
                    );
                }
            }
        };

        fused.requestLocationUpdates(req, callback, getMainLooper());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID,
                    "Location Tracker",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager m = getSystemService(NotificationManager.class);
            if (m != null) m.createNotificationChannel(c);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // intent is null when START_STICKY restarts the service after being killed
        // scheduleWatchdog() doesn't use intent so safe to call regardless
        scheduleWatchdog();
        return START_STICKY;
    }

    /**
     * Schedules a one-shot alarm 5 minutes from now using setExactAndAllowWhileIdle
     * so it fires even during Android Doze mode. WatchdogReceiver will reschedule
     * itself, creating a self-chaining loop independent of the service lifecycle.
     */
    void scheduleWatchdog() {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent watchdog = new Intent(getApplicationContext(), WatchdogReceiver.class);
        watchdog.setAction(WATCHDOG_ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(
                getApplicationContext(), 0, watchdog,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        long triggerAt = SystemClock.elapsedRealtime() + WATCHDOG_INTERVAL_MS;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+: check permission before using exact alarm
            if (am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
            } else {
                // Fallback: inexact but still wakes during Doze
                am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
        } else {
            am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
        }
    }

    void cancelWatchdog() {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent watchdog = new Intent(getApplicationContext(), WatchdogReceiver.class);
        watchdog.setAction(WATCHDOG_ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(
                getApplicationContext(), 0, watchdog,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // App swiped from recents — trigger immediate restart (1 sec) if tracking active
        // The 5-min periodic watchdog is already scheduled independently
        boolean shouldRun = getSharedPreferences("location_tracker_prefs", Context.MODE_PRIVATE)
                .getBoolean("tracking_enabled", false);
        if (shouldRun) {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                Intent watchdog = new Intent(getApplicationContext(), WatchdogReceiver.class);
                watchdog.setAction(WATCHDOG_ACTION);
                PendingIntent pi = PendingIntent.getBroadcast(
                        getApplicationContext(), 1, watchdog,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 1000, pi);
            }
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (fused != null && callback != null) {
            fused.removeLocationUpdates(callback);
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        dbExecutor.shutdown();
        // Cancel watchdog ONLY when user explicitly stopped tracking
        boolean shouldRun = getSharedPreferences("location_tracker_prefs", Context.MODE_PRIVATE)
                .getBoolean("tracking_enabled", false);
        if (!shouldRun) {
            cancelWatchdog();
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
