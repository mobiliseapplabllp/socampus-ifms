Pod::Spec.new do |s|
  s.name = 'CapacitorLocationTrackerSqlite'
  s.version = '1.0.0'
  s.summary = 'Background location tracking with local storage only'
  s.license = 'MIT'
  s.homepage = 'https://github.com/example/capacitor-location-tracker-sqlite'
  s.author = ''
  s.source = { :git => 'https://github.com/example/capacitor-location-tracker-sqlite.git', :tag => s.version.to_s }
  s.source_files = 'ios/Plugin/**/*.{swift,h,m}'
  s.ios.deployment_target = '13.0'
  s.dependency 'Capacitor'
end
