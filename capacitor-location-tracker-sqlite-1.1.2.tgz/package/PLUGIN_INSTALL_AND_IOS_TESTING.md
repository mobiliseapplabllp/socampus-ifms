# Plugin install + iOS testing guide

Yeh document batata hai ke **capacitor-location-tracker-sqlite** ko apne Ionic/Capacitor app me kaise install karna hai aur **iOS par kaise test** karna hai.

---

## 1. Zaroori cheezein

- Ionic + **Capacitor 5** wala project (`@capacitor/core` ^5)
- **Android**: JDK, Android Studio
- **iOS**: Mac, Xcode, **physical iPhone** (background location simulator par reliable nahi hoti)

---

## 2. Plugin package (.tgz) banana

Plugin repo me:

```bash
cd /path/to/capacitor-location-tracker-sqlite
npm install
npm run build
npm pack
```

Output file: **`capacitor-location-tracker-sqlite-1.0.0.tgz`** (same folder me banegi).

Har baar native code change ke baad dubara `npm run build` + `npm pack` karo, phir consumer app me nayi `.tgz` install karo.

---

## 3. Apne app me plugin install karna

```bash
cd /path/to/your-ionic-app
npm install /full/path/to/capacitor-location-tracker-sqlite-1.0.0.tgz
npx cap sync
```

**Example** (relative path):

```bash
npm install ../capacitor-location-tracker-sqlite/capacitor-location-tracker-sqlite-1.0.0.tgz
npx cap sync
```

---

## 4. TypeScript se use

```typescript
import { LocationTracker } from 'capacitor-location-tracker-sqlite';
```

Methods: `start`, `stop`, `getLocations`, `clearLocations`, `requestBackgroundPermissionsCheck`, `requestBackgroundPermissions`, `requestIgnoreBatteryOptimizationsCheck`, `requestIgnoreBatteryOptimizations`, `ping`.

---

## 5. Android (short checklist)

1. **`MainActivity.java`** me `Bundle` import + plugin register:

```java
import android.os.Bundle;
import com.locationtracker.sqlite.LocationTrackerPlugin;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(LocationTrackerPlugin.class);
    super.onCreate(savedInstanceState);
  }
}
```

2. `npx cap sync android`  
3. Runtime permissions app flow se (fine, background, notifications Android 13+).  
4. Zyada detail: **[INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)** section 3.

---

## 6. iOS setup

### 6.1 Sync

```bash
npx cap sync ios
cd ios/App && pod install && cd ../..
```

Agar Xcode se open karte ho to **`App.xcworkspace`** use karo, `.xcodeproj` nahi.

### 6.2 Info.plist (zaroori)

**Path (typical):** `ios/App/App/Info.plist`

Ye keys add / verify karo:

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>App needs your location while in use for tracking.</string>

<key>NSLocationAlwaysAndWhenInUseUsageDescription</key>
<string>App needs your location in background for continuous tracking.</string>

<key>UIBackgroundModes</key>
<array>
  <string>location</string>
</array>
```

iOS 11+ ke liye “always” text wala key important hai; bina iske prompt / review me problem aa sakti hai.

### 6.3 Native tracker (important)

`TrackerService` **sirf `start()` ke andar**, jab `authorizedAlways` ho, tab `allowsBackgroundLocationUpdates = true` set karta hai. Agar ye flag `init()` me pehle se `true` ho to iOS aksar **background location updates ignore** kar deta hai — isliye plugin v1.1.1+ me yeh order fix hai.

### 6.4 Podfile

`npx cap sync` ke baad zyada tar projects me plugin pod auto add ho jata hai. Agar build error aaye to **[INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)** section 5.1 dekho (`CapacitorLocationTrackerSqlite` path).

### 6.5 Xcode capabilities (optional check)

Target → **Signing & Capabilities** → agar “Background Modes” manually add karna pade to **Location updates** enable karo (Info.plist ke `UIBackgroundModes` ke saath align hona chahiye).

---

## 7. iOS par kaise test karna hai

### 7.1 Device par kyun?

Background location **real iPhone** par test karo. Simulator par GPS / background behavior incomplete ya misleading ho sakta hai.

### 7.2 Pehli baar install / permissions

1. App install karo, khol ke **permission flow** chalao:
   - `await LocationTracker.requestBackgroundPermissionsCheck()`
   - agar `allowed` false ho to `await LocationTracker.requestBackgroundPermissions()`
2. System dialog me **“Always Allow”** / **“Allow While Using App”** ke baad Settings se **Always** select karo (iOS version ke hisaab se flow thoda alag hota hai).
3. `await LocationTracker.start()` — success aana chahiye.

### 7.3 Tracking verify karna

1. `start()` ke baad thodi der chalao / ghoomo (GPS fix ke liye).  
2. `await LocationTracker.getLocations()` — array me `latitude`, `longitude`, `timestamp` (string, epoch **milliseconds**) aane chahiye.  
3. `await LocationTracker.stop()` — updates band.  
4. `await LocationTracker.clearLocations()` — local list clear.

### 7.4 Lock screen test

1. `start()` call karo, kuch points save hone do.  
2. Phone **lock** karo (app force-close mat karo).  
3. 5–15 minute baad unlock karke `getLocations()` dekho — naye points aane chahiye (network/GPS / Apple power policy ke hisaab se interval vary ho sakta hai).

### 7.5 Background (home button / app switcher)

App ko background bhejo, lock na bhi karo — phir bhi points aane chahiye jab `Always` permission ho aur `UIBackgroundModes` + `location` sahi ho.

### 7.6 Force kill (swipe up se app band)

**Important:** User ne app ko **force kill** kiya to iOS Android jaisa continuous foreground service **guarantee nahi** karta. Kabhi-kabhi significant location / relaunch se limited recovery ho sakti hai; product expectation Android jaisi “kill ke baad bhi same” mat rakho.

### 7.7 Debug tips

- Xcode → **Window → Devices and Simulators** → device logs filter: `LocationTracker`  
- Agar `start()` reject kare: pehle `requestBackgroundPermissionsCheck()` se `authorizedAlways` confirm karo.

---

## 8. Android vs iOS — short note

| Topic | Android | iOS |
|-------|---------|-----|
| Storage | SQLite | UserDefaults (local list) |
| Background | Foreground service + notification | `CLLocationManager` + background location mode |
| Battery optimization APIs | Real checks / settings | Same naam ke methods compatibility ke liye; iOS par system API equivalent nahi |
| App force kill | Service model alag | Reliable continuous tracking expect mat karo |

---

## 9. Aur docs

- **[QUICK_START.md](QUICK_START.md)** — .tgz + sample Angular flow  
- **[INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)** — Android manifest, permissions, battery, iOS Podfile detail  
- **[README.md](README.md)** — API table + overview  
