import Foundation
import CoreLocation

/// Background location + persistence (UserDefaults on iOS; mirrors Android flow).
/// Apple: `allowsBackgroundLocationUpdates` must be enabled only after `authorizedAlways`, typically on main queue right before updates.
final class TrackerService: NSObject, CLLocationManagerDelegate {

    static let shared = TrackerService()

    private let manager = CLLocationManager()

    private let MAX_ACCURACY: CLLocationAccuracy = 40
    private let STALE_TIME: TimeInterval = 15

    private var lastLat: Double = 0
    private var lastLng: Double = 0
    private var lastTime: TimeInterval = 0

    private var gpsReady = false
    private var warmupCount = 0

    private override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.distanceFilter = 20
        manager.pausesLocationUpdatesAutomatically = false
        // Do NOT set allowsBackgroundLocationUpdates here — only after authorizedAlways in start().
    }

    private func currentAuthorizationStatus() -> CLAuthorizationStatus {
        if #available(iOS 14.0, *) {
            return manager.authorizationStatus
        }
        return CLLocationManager.authorizationStatus()
    }

    func start() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            guard self.currentAuthorizationStatus() == .authorizedAlways else {
                print("LocationTracker: start() ignored — need Always location permission")
                return
            }

            self.gpsReady = false
            self.warmupCount = 0

            self.manager.allowsBackgroundLocationUpdates = true
            if #available(iOS 11.0, *) {
                self.manager.showsBackgroundLocationIndicator = true
            }

            self.manager.startUpdatingLocation()
            self.manager.startMonitoringSignificantLocationChanges()
            print("LocationTracker: TrackerService started (iOS), background updates ON")
        }
    }

    func stop() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.manager.stopUpdatingLocation()
            self.manager.stopMonitoringSignificantLocationChanges()
            self.manager.allowsBackgroundLocationUpdates = false
            print("LocationTracker: TrackerService stopped (iOS)")
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }

        if abs(loc.timestamp.timeIntervalSinceNow) > STALE_TIME {
            return
        }

        let accuracy = loc.horizontalAccuracy
        let speed = max(loc.speed, 0)

        if accuracy <= 0 || accuracy > MAX_ACCURACY {
            return
        }

        if !gpsReady {
            warmupCount += 1
            if accuracy <= 30 && speed > 0 {
                gpsReady = true
                print("LocationTracker: GPS warmed up (iOS)")
            } else {
                if warmupCount < 3 { return }
            }
        }

        let lat = loc.coordinate.latitude
        let lng = loc.coordinate.longitude

        var minMove: CLLocationDistance
        var maxJump: CLLocationDistance

        if speed < 0.5 {
            minMove = 30; maxJump = 50
        } else if speed < 2 {
            minMove = 15; maxJump = 80
        } else if speed < 6 {
            minMove = 25; maxJump = 150
        } else {
            minMove = 50; maxJump = 300
        }

        if lastLat != 0 && lastLng != 0 {
            let lastLoc = CLLocation(latitude: lastLat, longitude: lastLng)
            let dist = loc.distance(from: lastLoc)
            if dist < minMove { return }
            if dist > maxJump { return }
        }

        lastLat = lat
        lastLng = lng
        lastTime = Date().timeIntervalSince1970

        LocationDbHelper.shared.insertLocation(loc)

        print("LocationTracker: Accepted iOS location:", lat, lng, "acc:", accuracy, "speed:", speed)
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("LocationTracker: Location error:", error.localizedDescription)
    }
}
