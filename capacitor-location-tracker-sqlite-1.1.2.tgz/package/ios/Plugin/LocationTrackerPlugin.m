#import <Foundation/Foundation.h>
#import <Capacitor/Capacitor.h>

CAP_PLUGIN(LocationTrackerPlugin, "LocationTracker",
           CAP_PLUGIN_METHOD(start, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(stop, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(getLocations, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(clearLocations, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(requestBackgroundPermissionsCheck, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(requestBackgroundPermissions, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(requestIgnoreBatteryOptimizationsCheck, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(requestIgnoreBatteryOptimizations, CAPPluginReturnPromise);
           CAP_PLUGIN_METHOD(ping, CAPPluginReturnPromise);
)
