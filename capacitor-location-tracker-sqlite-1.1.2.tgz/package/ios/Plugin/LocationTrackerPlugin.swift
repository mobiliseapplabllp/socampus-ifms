import Foundation
import Capacitor
import CoreLocation
import UIKit

/// iOS 13+: Apple expects "When In Use" first, then `requestAlwaysAuthorization()` for the
/// "Always" upgrade sheet. Calling only `requestAlwaysAuthorization()` from `.notDetermined`
/// often never shows the full Always flow.
@objc(LocationTrackerPlugin)
public class LocationTrackerPlugin: CAPPlugin, CLLocationManagerDelegate {

    private let permissionManager = CLLocationManager()
    private var pendingPermissionCall: CAPPluginCall?

    /// After first prompt we move to Always upgrade; second `.authorizedWhenInUse` means user kept "While Using" only.
    private enum AlwaysPermissionStage {
        case idle
        case waitingWhenInUse
        case waitingAlwaysUpgrade
    }

    private var alwaysPermissionStage: AlwaysPermissionStage = .idle
    /// After showing the Always upgrade sheet, ignore spurious `.authorizedWhenInUse` until this is true (see Apple delegate ordering).
    private var canTreatWhenInUseAsDeclinedAlways = false
    private var allowWhenInUseDeclineWorkItem: DispatchWorkItem?

    override public func load() {
        permissionManager.delegate = self
        print("LocationTracker: Plugin loaded")
    }

    private func getAuthStatus() -> CLAuthorizationStatus {
        if #available(iOS 14.0, *) {
            return permissionManager.authorizationStatus
        } else {
            return CLLocationManager.authorizationStatus()
        }
    }

    @objc func start(_ call: CAPPluginCall) {
        let status = getAuthStatus()

        guard status == .authorizedAlways else {
            call.reject("Background location permission not granted")
            return
        }

        DispatchQueue.main.async {
            TrackerService.shared.start()
        }

        call.resolve(["success": true])
    }

    @objc func stop(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            TrackerService.shared.stop()
        }
        call.resolve(["success": true])
    }

    @objc func getLocations(_ call: CAPPluginCall) {
        let locations = LocationDbHelper.shared.getAllLocations()
        call.resolve(["locations": locations])
    }

    @objc func clearLocations(_ call: CAPPluginCall) {
        LocationDbHelper.shared.clearLocations()
        call.resolve(["success": true])
    }

    @objc func requestBackgroundPermissionsCheck(_ call: CAPPluginCall) {
        let status = getAuthStatus()
        let allowed = (status == .authorizedAlways)
        call.resolve([
            "allowed": allowed,
            "status": status.rawValue
        ])
    }

    @objc func requestBackgroundPermissions(_ call: CAPPluginCall) {
        let status = getAuthStatus()

        if status == .authorizedAlways {
            call.resolve(["opened": false, "allowed": true])
            return
        }

        pendingPermissionCall = call
        alwaysPermissionStage = .idle

        if status == .notDetermined {
            alwaysPermissionStage = .waitingWhenInUse
            DispatchQueue.main.async {
                self.permissionManager.requestWhenInUseAuthorization()
            }
            return
        }

        if status == .authorizedWhenInUse {
            alwaysPermissionStage = .waitingAlwaysUpgrade
            scheduleAllowWhenInUseDeclineDetection()
            DispatchQueue.main.async {
                self.permissionManager.requestAlwaysAuthorization()
            }
            return
        }

        pendingPermissionCall = nil
        alwaysPermissionStage = .idle

        DispatchQueue.main.async {
            if let url = URL(string: UIApplication.openSettingsURLString),
               UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
                call.resolve(["opened": true, "allowed": false])
            } else {
                call.resolve(["opened": false, "allowed": false])
            }
        }
    }

    @objc func requestIgnoreBatteryOptimizationsCheck(_ call: CAPPluginCall) {
        call.resolve(["allowed": true])
    }

    @objc func requestIgnoreBatteryOptimizations(_ call: CAPPluginCall) {
        call.resolve(["success": true])
    }

    @objc func ping(_ call: CAPPluginCall) {
        call.resolve(["pong": true])
    }

    private func finishPermissionCall(allowed: Bool, openedSettings: Bool = false) {
        allowWhenInUseDeclineWorkItem?.cancel()
        allowWhenInUseDeclineWorkItem = nil
        canTreatWhenInUseAsDeclinedAlways = false
        guard let call = pendingPermissionCall else { return }
        call.resolve(["opened": openedSettings, "allowed": allowed])
        pendingPermissionCall = nil
        alwaysPermissionStage = .idle
    }

    private func scheduleAllowWhenInUseDeclineDetection() {
        allowWhenInUseDeclineWorkItem?.cancel()
        canTreatWhenInUseAsDeclinedAlways = false
        let work = DispatchWorkItem { [weak self] in
            self?.canTreatWhenInUseAsDeclinedAlways = true
        }
        allowWhenInUseDeclineWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.65, execute: work)
    }

    private func handleAuthorizationChange() {
        guard pendingPermissionCall != nil else { return }

        let status = getAuthStatus()

        switch status {
        case .authorizedAlways:
            finishPermissionCall(allowed: true)

        case .authorizedWhenInUse:
            switch alwaysPermissionStage {
            case .waitingWhenInUse:
                alwaysPermissionStage = .waitingAlwaysUpgrade
                scheduleAllowWhenInUseDeclineDetection()
                DispatchQueue.main.async {
                    self.permissionManager.requestAlwaysAuthorization()
                }
            case .waitingAlwaysUpgrade:
                if canTreatWhenInUseAsDeclinedAlways {
                    finishPermissionCall(allowed: false)
                }
            case .idle:
                break
            }

        case .denied, .restricted:
            finishPermissionCall(allowed: false)

        case .notDetermined:
            break

        @unknown default:
            finishPermissionCall(allowed: false)
        }
    }

    public func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if #available(iOS 14.0, *) {
            handleAuthorizationChange()
        }
    }

    public func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if #available(iOS 14.0, *) {
            return
        }
        handleAuthorizationChange()
    }
}
