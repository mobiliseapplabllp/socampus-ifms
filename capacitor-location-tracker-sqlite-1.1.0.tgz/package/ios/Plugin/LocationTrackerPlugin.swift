import Foundation
import Capacitor
import CoreLocation
import UIKit

@objc(LocationTrackerPlugin)
public class LocationTrackerPlugin: CAPPlugin, CLLocationManagerDelegate {

    private let permissionManager = CLLocationManager()
    private var pendingPermissionCall: CAPPluginCall?

    override public func load() {
        permissionManager.delegate = self
        print("LocationTracker: Plugin loaded")
    }

    private func getAuthStatus() -> CLAuthorizationStatus {
        if #available(iOS 14.0, *) {
            return CLLocationManager().authorizationStatus
        } else {
            return CLLocationManager.authorizationStatus()
        }
    }

    @objc func start(_ call: CAPPluginCall) {
        let status = getAuthStatus()

        guard status == .authorizedAlways else {
            call.reject("Background location permission not granted")
            return
        }

        DispatchQueue.main.async {
            TrackerService.shared.start()
        }

        call.resolve(["success": true])
    }

    @objc func stop(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            TrackerService.shared.stop()
        }
        call.resolve(["success": true])
    }

    @objc func getLocations(_ call: CAPPluginCall) {
        let locations = LocationDbHelper.shared.getAllLocations()
        call.resolve(["locations": locations])
    }

    @objc func clearLocations(_ call: CAPPluginCall) {
        LocationDbHelper.shared.clearLocations()
        call.resolve(["success": true])
    }

    @objc func requestBackgroundPermissionsCheck(_ call: CAPPluginCall) {
        let status = getAuthStatus()
        let allowed = (status == .authorizedAlways)
        call.resolve([
            "allowed": allowed,
            "status": status.rawValue
        ])
    }

    @objc func requestBackgroundPermissions(_ call: CAPPluginCall) {
        let status = getAuthStatus()

        if status == .authorizedAlways {
            call.resolve(["opened": false, "allowed": true])
            return
        }

        // First-time flow: trigger the native iOS prompt.
        if status == .notDetermined {
            pendingPermissionCall = call
            DispatchQueue.main.async {
                self.permissionManager.requestAlwaysAuthorization()
            }
            return
        }

        // Once denied/limited, iOS allows change via Settings only.
        DispatchQueue.main.async {
            if let url = URL(string: UIApplication.openSettingsURLString),
               UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
                call.resolve(["opened": true, "allowed": false])
            } else {
                call.resolve(["opened": false, "allowed": false])
            }
        }
    }

    @objc func requestIgnoreBatteryOptimizationsCheck(_ call: CAPPluginCall) {
        call.resolve(["allowed": true])
    }

    @objc func requestIgnoreBatteryOptimizations(_ call: CAPPluginCall) {
        call.resolve(["success": true])
    }

    @objc func ping(_ call: CAPPluginCall) {
        call.resolve(["pong": true])
    }

    public func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        guard let call = pendingPermissionCall else { return }

        let allowed = (getAuthStatus() == .authorizedAlways)
        call.resolve(["opened": false, "allowed": allowed])
        pendingPermissionCall = nil
    }

    public func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        guard let call = pendingPermissionCall else { return }

        let allowed = (status == .authorizedAlways)
        call.resolve(["opened": false, "allowed": allowed])
        pendingPermissionCall = nil
    }
}
