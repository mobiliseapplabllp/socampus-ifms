package com.locationtracker.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;

public class LocationDbHelper extends SQLiteOpenHelper {

    private static final String DB = "location_tracker_locations.db";
    private static final int VER = 1;
    private static LocationDbHelper instance;

    public static synchronized LocationDbHelper getInstance(Context ctx) {
        if (instance == null) {
            instance = new LocationDbHelper(ctx.getApplicationContext());
        }
        return instance;
    }

    public LocationDbHelper(Context context) {
        super(context, DB, null, VER);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS locations (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "latitude REAL," +
                "longitude REAL," +
                "timestamp INTEGER" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS locations");
        onCreate(db);
    }

    public void insertLocation(double lat, double lng, long timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("latitude", lat);
        cv.put("longitude", lng);
        cv.put("timestamp", timestamp);
        db.insert("locations", null, cv);
    }

    public Cursor getAllLocations() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT latitude, longitude, timestamp FROM locations ORDER BY id ASC", null);
    }

    public void clearLocations() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("locations", null, null);
    }

    public Location getLastLocation() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT latitude, longitude, timestamp FROM locations ORDER BY id DESC LIMIT 1",
                null
        );

        Location loc = null;
        if (cursor != null && cursor.moveToFirst()) {
            loc = new Location("db");
            loc.setLatitude(cursor.getDouble(0));
            loc.setLongitude(cursor.getDouble(1));
            loc.setTime(cursor.getLong(2));
        }
        if (cursor != null) {
            cursor.close();
        }
        return loc;
    }
}
