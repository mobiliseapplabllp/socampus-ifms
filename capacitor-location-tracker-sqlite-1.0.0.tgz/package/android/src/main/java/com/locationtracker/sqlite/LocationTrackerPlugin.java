package com.locationtracker.sqlite;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "LocationTracker", requestCodes = {1001})
public class LocationTrackerPlugin extends Plugin {

    @PluginMethod
    public void start(PluginCall call) {
        Context context = getContext();

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            call.reject("Location permission not granted");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            call.reject("Background location permission not granted");
            return;
        }

        try {
            Intent i = new Intent(context, TrackerService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i);
            } else {
                context.startService(i);
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to start service: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try {
            Intent i = new Intent(getContext(), TrackerService.class);
            getContext().stopService(i);
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to stop service: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void getLocations(PluginCall call) {
        try {
            LocationDbHelper dbHelper = LocationDbHelper.getInstance(getContext());
            Cursor cursor = dbHelper.getAllLocations();

            JSArray arr = new JSArray();
            if (cursor.moveToFirst()) {
                do {
                    JSObject obj = new JSObject();
                    obj.put("latitude", cursor.getDouble(0));
                    obj.put("longitude", cursor.getDouble(1));
                    obj.put("timestamp", String.valueOf(cursor.getLong(2)));
                    arr.put(obj);
                } while (cursor.moveToNext());
            }
            cursor.close();

            JSObject ret = new JSObject();
            ret.put("locations", arr);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to fetch locations: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void clearLocations(PluginCall call) {
        try {
            LocationDbHelper dbHelper = LocationDbHelper.getInstance(getContext());
            dbHelper.clearLocations();
            call.resolve();
        } catch (Exception e) {
            call.reject("Failed to clear locations: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void requestBackgroundPermissionsCheck(PluginCall call) {
        try {
            Context context = getContext();
            boolean allowed = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                allowed = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED;
            }
            JSObject ret = new JSObject();
            ret.put("allowed", allowed);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Location permission error: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestBackgroundPermissions(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve(new JSObject().put("opened", true));
        } catch (Exception e) {
            call.reject("Open location settings failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestIgnoreBatteryOptimizationsCheck(PluginCall call) {
        try {
            Context context = getContext();
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            boolean ignoring = pm != null && pm.isIgnoringBatteryOptimizations(context.getPackageName());
            JSObject ret = new JSObject();
            ret.put("allowed", ignoring);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Battery check failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestIgnoreBatteryOptimizations(PluginCall call) {
        try {
            Context context = getContext();
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(context.getPackageName())) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (getActivity() != null) {
                    getActivity().startActivity(intent);
                } else {
                    context.startActivity(intent);
                }
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to request battery optimizations: " + e.getMessage());
        }
    }

    @PluginMethod
    public void ping(PluginCall call) {
        call.resolve(new JSObject().put("pong", true));
    }
}
