package com.locationtracker.sqlite;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

public class TrackerService extends Service {

    private static final String CHANNEL_ID = "location_tracker_channel";
    private static final float MAX_ACCURACY = 40f;
    private static final int NOTIF_ID = 1;

    private double lastLat = 0;
    private double lastLng = 0;
    private long lastTime = 0;

    private boolean gpsReady = false;
    private int warmupCount = 0;

    private FusedLocationProviderClient fused;
    private LocationCallback callback;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();

        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Location Tracker")
                .setContentText("Background location active")
                .setSmallIcon(com.locationtracker.sqlite.R.drawable.ic_location_tracker)
                .setOngoing(true)
                .build();

        startForeground(NOTIF_ID, n);

        Location last = LocationDbHelper.getInstance(getApplicationContext()).getLastLocation();
        if (last != null) {
            lastLat = last.getLatitude();
            lastLng = last.getLongitude();
            lastTime = last.getTime();
            Log.d("LocationTracker", "Restored last location from DB");
        }

        fused = LocationServices.getFusedLocationProviderClient(this);
        startLocationUpdates();
    }

    private void startLocationUpdates() {
        LocationRequest req;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            req = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10_000)
                    .setMinUpdateIntervalMillis(5_000)
                    .setMinUpdateDistanceMeters(20)
                    .build();
        } else {
            req = LocationRequest.create()
                    .setInterval(10_000)
                    .setFastestInterval(5_000)
                    .setSmallestDisplacement(20)
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }

        callback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult result) {
                if (result == null) return;

                for (Location loc : result.getLocations()) {
                    if (System.currentTimeMillis() - loc.getTime() > 15000) continue;

                    float accuracy = loc.getAccuracy();
                    float speed = loc.hasSpeed() ? loc.getSpeed() : 0f;

                    if (accuracy == 0 || accuracy > MAX_ACCURACY) continue;

                    if (!gpsReady) {
                        warmupCount++;
                        if (accuracy <= 30 && loc.hasSpeed()) {
                            gpsReady = true;
                            Log.d("LocationTracker", "GPS warmed up");
                        } else {
                            if (warmupCount < 3) continue;
                        }
                    }

                    double lat = loc.getLatitude();
                    double lng = loc.getLongitude();

                    float minMove, maxJump;
                    if (speed < 0.5f) {
                        minMove = 30;
                        maxJump = 50;
                    } else if (speed < 2f) {
                        minMove = 15;
                        maxJump = 80;
                    } else if (speed < 6f) {
                        minMove = 25;
                        maxJump = 150;
                    } else {
                        minMove = 50;
                        maxJump = 300;
                    }

                    if (lastLat != 0 && lastLng != 0) {
                        float[] dist = new float[1];
                        Location.distanceBetween(lastLat, lastLng, lat, lng, dist);
                        if (dist[0] < minMove) continue;
                        if (dist[0] > maxJump) continue;
                    }

                    lastLat = lat;
                    lastLng = lng;
                    lastTime = System.currentTimeMillis();

                    LocationDbHelper.getInstance(getApplicationContext()).insertLocation(lat, lng, lastTime);
                }
            }
        };

        fused.requestLocationUpdates(req, callback, getMainLooper());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID,
                    "Location Tracker",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager m = getSystemService(NotificationManager.class);
            if (m != null) m.createNotificationChannel(c);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (fused != null && callback != null) {
            fused.removeLocationUpdates(callback);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
