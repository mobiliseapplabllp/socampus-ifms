# capacitor-location-tracker-sqlite

Background location tracking plugin for Capacitor. Saves locations **only to SQLite** (Android) / UserDefaults (iOS) — no server sync, no API calls, no token.

## Quick Setup Checklist

| Step | Action |
|------|--------|
| 1 | `npm install capacitor-location-tracker-sqlite` |
| 2 | **Android**: Add `registerPlugin(LocationTrackerPlugin.class)` in MainActivity |
| 3 | **Android**: Ensure AndroidManifest has permissions + `TrackerService` (see INSTALLATION_GUIDE) |
| 4 | **iOS**: Add pod in Podfile + Info.plist keys (`NSLocationAlwaysAndWhenInUseUsageDescription`, `UIBackgroundModes`) |
| 5 | `npx cap sync` |

## Installation

### In your Ionic/Capacitor project:

```bash
# Local path (development)
npm install ../capacitor-location-tracker-sqlite

# Or after publishing to npm
npm install capacitor-location-tracker-sqlite
```

### Add to your app

1. **Register the plugin** in your app's MainActivity (Android) - add to `onCreate`:

```java
import com.locationtracker.sqlite.LocationTrackerPlugin;

// In onCreate:
registerPlugin(LocationTrackerPlugin.class);
```

2. **Add the pod** (iOS) - in your Podfile's `capacitor_pods`:

```ruby
pod 'CapacitorLocationTrackerSqlite', :path => '../../node_modules/capacitor-location-tracker-sqlite'
```

3. **Sync native projects**:

```bash
npx cap sync
```

### Required app configuration

See **[INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)** for full details including:
- AndroidManifest.xml permissions and service
- TypeScript ↔ Java bridge
- Battery optimization
- MainActivity plugin registration
- iOS Podfile and Info.plist

## Usage

```typescript
import { LocationTracker } from 'capacitor-location-tracker-sqlite';

// Start tracking
await LocationTracker.start();

// Stop tracking
await LocationTracker.stop();

// Get saved locations
const { locations } = await LocationTracker.getLocations();

// Clear locations
await LocationTracker.clearLocations();

// Check/set permissions
const { allowed } = await LocationTracker.requestBackgroundPermissionsCheck();
await LocationTracker.requestBackgroundPermissions(); // Opens app settings
await LocationTracker.requestIgnoreBatteryOptimizationsCheck();
await LocationTracker.requestIgnoreBatteryOptimizations(); // Opens battery settings
```

## API

| Method | Returns |
|--------|---------|
| `start()` | `Promise<{ success: boolean }>` |
| `stop()` | `Promise<{ success: boolean }>` |
| `getLocations()` | `Promise<{ locations: Array<{ latitude, longitude, timestamp }> }>` |
| `clearLocations()` | `Promise<void>` |
| `requestBackgroundPermissionsCheck()` | `Promise<{ allowed: boolean }>` |
| `requestBackgroundPermissions()` | `Promise<{ opened: boolean }>` |
| `requestIgnoreBatteryOptimizationsCheck()` | `Promise<{ allowed: boolean }>` |
| `requestIgnoreBatteryOptimizations()` | `Promise<{ success: boolean }>` |
| `ping()` | `Promise<{ pong: boolean }>` |

## Differences from BackgroundTracker (clr-service)

- **No server sync** – locations are saved locally only
- **No token** – `setToken` and `syncNow` methods removed
- **Simplified schema** – no `isSynced` field
