import Foundation
import CoreLocation

final class LocationDbHelper {

    static let shared = LocationDbHelper()

    private let STORAGE_KEY = "LOCATION_TRACKER_SQLITE_LOCATIONS"

    struct StoredLocation {
        let latitude: Double
        let longitude: Double
        let timestamp: TimeInterval
    }

    private init() {}

    func insertLocation(latitude: Double, longitude: Double, timestamp: TimeInterval) {
        var all = loadAllInternal()
        let item = StoredLocation(latitude: latitude, longitude: longitude, timestamp: timestamp)
        all.append(item)
        persist(all)
    }

    func insertLocation(_ loc: CLLocation) {
        insertLocation(
            latitude: loc.coordinate.latitude,
            longitude: loc.coordinate.longitude,
            timestamp: loc.timestamp.timeIntervalSince1970
        )
    }

    func getAllLocations() -> [[String: Any]] {
        return loadAllInternal().map {
            [
                "latitude": $0.latitude,
                "longitude": $0.longitude,
                "timestamp": String(Int($0.timestamp * 1000))
            ]
        }
    }

    func clearLocations() {
        UserDefaults.standard.removeObject(forKey: STORAGE_KEY)
    }

    func getLastLocation() -> CLLocation? {
        guard let last = loadAllInternal().last else { return nil }

        return CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: last.latitude, longitude: last.longitude),
            altitude: 0,
            horizontalAccuracy: 10,
            verticalAccuracy: -1,
            timestamp: Date(timeIntervalSince1970: last.timestamp)
        )
    }

    private func loadAllInternal() -> [StoredLocation] {
        guard let raw = UserDefaults.standard.array(forKey: STORAGE_KEY) as? [[String: Any]] else {
            return []
        }

        return raw.compactMap { dict in
            guard
                let lat = dict["latitude"] as? Double,
                let lng = dict["longitude"] as? Double,
                let ts = dict["timestamp"] as? TimeInterval
            else { return nil }

            return StoredLocation(latitude: lat, longitude: lng, timestamp: ts)
        }
    }

    private func persist(_ items: [StoredLocation]) {
        let raw = items.map {
            [
                "latitude": $0.latitude,
                "longitude": $0.longitude,
                "timestamp": $0.timestamp
            ]
        }
        UserDefaults.standard.set(raw, forKey: STORAGE_KEY)
    }
}
