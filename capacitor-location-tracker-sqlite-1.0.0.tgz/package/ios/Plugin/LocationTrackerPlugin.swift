import Foundation
import Capacitor
import CoreLocation
import UIKit

@objcMembers
@objc(LocationTracker)
public class LocationTrackerPlugin: CAPPlugin {

    override public func load() {
        print("LocationTracker: Plugin loaded")
    }

    private func getAuthStatus() -> CLAuthorizationStatus {
        if #available(iOS 14.0, *) {
            return CLLocationManager().authorizationStatus
        } else {
            return CLLocationManager.authorizationStatus()
        }
    }

    @objc func start(_ call: CAPPluginCall) {
        let status = getAuthStatus()

        guard status == .authorizedAlways else {
            call.reject("Background location permission not granted")
            return
        }

        DispatchQueue.main.async {
            TrackerService.shared.start()
        }

        call.resolve(["success": true])
    }

    @objc func stop(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            TrackerService.shared.stop()
        }
        call.resolve(["success": true])
    }

    @objc func getLocations(_ call: CAPPluginCall) {
        let locations = LocationDbHelper.shared.getAllLocations()
        call.resolve(["locations": locations])
    }

    @objc func clearLocations(_ call: CAPPluginCall) {
        LocationDbHelper.shared.clearLocations()
        call.resolve(["success": true])
    }

    @objc func requestBackgroundPermissionsCheck(_ call: CAPPluginCall) {
        let status = getAuthStatus()
        let allowed = (status == .authorizedAlways)
        call.resolve([
            "allowed": allowed,
            "status": status.rawValue
        ])
    }

    @objc func requestBackgroundPermissions(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        }
        call.resolve(["opened": true])
    }

    @objc func requestIgnoreBatteryOptimizationsCheck(_ call: CAPPluginCall) {
        call.resolve(["allowed": true])
    }

    @objc func requestIgnoreBatteryOptimizations(_ call: CAPPluginCall) {
        call.resolve(["success": true])
    }

    @objc func ping(_ call: CAPPluginCall) {
        call.resolve(["pong": true])
    }
}
